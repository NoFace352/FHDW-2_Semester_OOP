package de.fhdw.auebung.command;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InvokerTest {
    @Test
    void test(){
        Item schwert1 = new Item("Blutfeuer", 50);
        Item schwert2 = new Item("Laubklinge", 80);

        Invoker schwertInvoker = new Invoker();

        ItemHitPointEvent hpEvent = new ItemHitPointEvent(schwert1);
        ItemNameEvent nEvent = new ItemNameEvent(schwert2, "Herbstblatt");


        schwertInvoker.execute(hpEvent);
        assertEquals(55, schwert1.getDmg());

        schwertInvoker.execute(hpEvent);
        assertEquals(60, schwert1.getDmg());

        schwertInvoker.execute(hpEvent);
        assertEquals(65, schwert1.getDmg());

        schwertInvoker.execute(hpEvent);
        assertEquals(70, schwert1.getDmg());

        schwertInvoker.undo(hpEvent);
        assertEquals(65, schwert1.getDmg());

        schwertInvoker.undo(hpEvent);
        assertEquals(60, schwert1.getDmg());

        schwertInvoker.undo(hpEvent);
        assertEquals(55, schwert1.getDmg());

        schwertInvoker.redo(hpEvent);
        assertEquals(60, schwert1.getDmg());

        schwertInvoker.execute(hpEvent);
        assertEquals(65, schwert1.getDmg());

        schwertInvoker.undo(hpEvent);
        assertEquals(60, schwert1.getDmg());

        schwertInvoker.undo(hpEvent);
        assertNotEquals(55, schwert1.getDmg());



        schwertInvoker.execute(nEvent);
        assertEquals("Herbstblatt", schwert2.getName());

        schwertInvoker.execute(nEvent);
        assertEquals("Herbstblatt1", schwert2.getName());

        schwertInvoker.execute(nEvent);
        assertEquals("Herbstblatt2", schwert2.getName());

        schwertInvoker.undo(nEvent);
        assertEquals("Herbstblatt1", schwert2.getName());

        schwertInvoker.execute(nEvent);
        assertEquals("Herbstblatt2", schwert2.getName());
    }

}