package de.fhdw.auebung.command;

public class ItemNameEvent implements Command{

    private Item schwert;
    private String name;

    public ItemNameEvent(Item schwert, String name) {
        this.schwert = schwert;
        this.name = name;
    }

    @Override
    public void execute() {
        schwert.setName(name);
    }

    @Override
    public void undo() {

    }

    @Override
    public void redo() {

    }


}
