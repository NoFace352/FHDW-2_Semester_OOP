package de.fhdw.auebung.command;

public class ItemHitPointEvent implements Command{

    private Item schwert;


    public ItemHitPointEvent(Item schwert) {
        this.schwert = schwert;
    }

    @Override
    public void execute() {
        schwert.setDmg(schwert.getDmg() + 5);
    }

    @Override
    public void undo() {

    }

    @Override
    public void redo() {
    }

}
