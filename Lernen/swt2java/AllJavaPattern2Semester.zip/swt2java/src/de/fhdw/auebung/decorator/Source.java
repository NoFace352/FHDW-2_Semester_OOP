package de.fhdw.auebung.decorator;

public interface Source {
    int getRed();
    int getGreen();
    int getBlue();
}
