package de.fhdw.auebung.decorator;

public class WhiteLamp implements Source {
    @Override
    public int getRed() {
        return 255;
    }

    @Override
    public int getGreen() {
        return 255;
    }

    @Override
    public int getBlue() {
        return 255;
    }
}
